package com.tjoeunit.service;

import java.sql.SQLException;
import java.util.HashMap;

import com.ibatis.sqlmap.client.SqlMapClient;
import com.tjoeun.ibatis.MyAppSqlConfig;
import com.tjoeunit.dao.GuestbookDAO;
import com.tjoeunit.vo.GuestbookList;
import com.tjoeunit.vo.GuestbookVO;

public class SelectService {

	private static SelectService instance = new SelectService();
	private SelectService() { }
	public static SelectService getInstance() {
		return instance;
	}

//	list.jsp에서 호출되는 화면에 표시할 페이지 번호를 넘겨받고 mapper를 얻어온 후 DAO 클래스의 한 페이지 분량의
//	글 목록을 얻어오는 메소드를 호출하는 메소드
	public GuestbookList selectList(int currentPage) {
		System.out.println("SelectService 클래스의 selectList() 메소드 실행");
		SqlMapClient mapper = MyAppSqlConfig.getSqlMapInstance();
		
//		한 페이지 분량의 글과 페이지 작업에 사용할 8개의 변수 값을 저장하는 객체를 선언한다.
		GuestbookList guestbookList = null;
		GuestbookDAO dao = GuestbookDAO.getInstance();
		
		try {
//			한 페이지에 표시할 글의 개수를 정한다.
			int pageSize = 10;
//			테이블에 저장된 전체 글의 개수를 얻어온다.
			int totalCount = dao.selectCount(mapper);
//			System.out.println(totalCount);
			
//			pageSize, totalCount, currentPage를 생성자의 인수로 넘겨서 한 페이지 분량의 글과 페이지 작업에 사용할
//			8개의 변수를 초기화시키는 클래스(GuestbookList)의 객체를 생성한다.
			guestbookList = new GuestbookList(pageSize, totalCount, currentPage);
			
//			parameterClass와 resultClass는 반드시 데이터 타입을 1개만 적어야 한다.
			HashMap<String, Integer> hmap = new HashMap<String, Integer>();
			hmap.put("startNo", guestbookList.getStartNo());
			hmap.put("endNo", guestbookList.getEndNo());
			guestbookList.setGuestbookList(dao.selectList(mapper, hmap));
//			mysql을 사용한다면 아래와 같이 HashMap에 저장해서 넘겨야 한다.
//			hmap.put("startNo", guestbookList.getStartNo());
//			hmap.put("pageSize", guestbookList.getPageSize());
//			System.out.println(guestbookList);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return guestbookList;
	}
	
//	selectByIdx.jsp에서 호출되는 수정 또는 삭제할 글번호를 넘겨받고 mapper를 얻어온 후 DAO 클래스의 글 한건을
//	얻어오는 메소드를 호출하는 메소드
	public GuestbookVO selectByIdx(int idx) {
		System.out.println("SelectService 클래스의 selectByIdx() 메소드 실행");
		SqlMapClient mapper = MyAppSqlConfig.getSqlMapInstance();
		GuestbookVO vo = null;
		try {
			vo = GuestbookDAO.getInstance().selectByIdx(mapper, idx);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return vo;
	}
	
}















