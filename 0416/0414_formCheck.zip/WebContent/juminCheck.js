//	함수의 형식
//	function 함수이름([인수, ...]) {
//		함수가 실행할 문장;
//		...;
//		[return 값;]
//	}

//	이벤트가 실행되는 객체(주민등록번호 앞, 뒤자리)에 최대 글자수 만큼 문자가 입력되면
//	지정된 객체로 포커스를 넘겨주는 함수
//	moveNext(이벤트가 실행되는 객체, 최대 글자수, 포커스를 넘겨줄 객체)
	function moveNext(obj, len, nextObj) {
//		value => 객체에 입력된 데이터를 의미한다. 데이터가 입력된 상태면 true, 입력되지
//		않은 상태면 false
//		length => 객체에 입력된 문자의 개수
		if(obj.value.length == len) {
			nextObj.focus();
		}
	}
	
	function formCheck(obj) {
//		obj에는 this(폼)가 넘어오므로 document.juminForm이 저장된다.

//		주민등록번호 앞 자리에 데이터가 입력되었나 검사해서 입력되지 않았으면 에러
//		메시지를 출력하고 false를 리턴시킨다.
		if(!obj.j1.value || obj.j1.value.trim().length == 0) {
			alert("주민등록번호 앞자리를 입력하세요");
			obj.j1.value = "";
			obj.j1.focus();
			return false;
		}

//		주민등록번호 앞 자리에 6글자가 입력되었나 검사해서 입력되지 않았으면 에러
//		메시지를 출력하고 false를 리턴시킨다.
		if(obj.j1.value.trim().length != 6) {
			alert("주민등록번호 앞자리는 6글자를 입력하세요");
			obj.j1.value = "";
			obj.j1.focus();
			return false;
		}

//		주민등록번호 앞 자리에 숫자만 입력되었나 검사해서 숫자만 입력되지 않았으면 
//		에러 메시지를 출력하고 false를 리턴시킨다.
//		Number() : 인수로 지정된 문자열을 숫자로 변환한다.
//		isNaN() : NaN(Not a Number), 인수로 지정된 데이터가 숫자가 아니면 true, 숫자면
//		false를 리턴시킨다.
		if(isNaN(Number(obj.j1.value))) {
			alert("주민등록번호 앞자리는 숫자만 입력하세요");
			obj.j1.value = "";
			obj.j1.focus();
			return false;
		}

//		주민등록번호 뒷자리 유효성 검사
		if(!obj.j2.value || obj.j2.value.trim().length == 0) {
			alert("주민등록번호 뒷자리를 입력하세요");
			obj.j2.value = "";
			obj.j2.focus();
			return false;
		}
		if(obj.j2.value.trim().length != 7) {
			alert("주민등록번호 뒷자리는 7글자를 입력하세요");
			obj.j2.value = "";
			obj.j2.focus();
			return false;
		}
		if(isNaN(Number(obj.j2.value))) {
			alert("주민등록번호 뒷자리는 숫자만 입력하세요");
			obj.j2.value = "";
			obj.j2.focus();
			return false;
		}
		
//		여기까지 왔다는 것은 입력된 주민등록번호가 13자리의 숫자로 입력되었다는 
//		의미이다. => 주민등록번호 유효성을 검사한다.
//		주민등록번호 유효성을 검사하기 위해 하나의 문자열로 합친다.
//		자바스크립트는 숫자로만 구성된 문자열을 사칙연산을 할 경우 덧셈인 경우만
//		문자열을 붙여서 이어주고 덧셈을 제외한 나머지 연산은 지가 알아서 숫자로 
//		변환시켜 연산한다.
		var jumin = obj.j1.value + obj.j2.value;
//		var jumin = Number(obj.j1.value) + Number(obj.j2.value);
//		alert(jumin);

//		i            :   0   1   2   3   4   5   6   7   8   9  10  11
//		i % 8		 :   0   1   2   3   4   5   6   7   0   1   2   3
//		주민등록번호 :   8   3   0   4   2   2   1   1   8   5   6   0   0
//					     *   *   *   *   *   *   *   *   *   *   *   *
//		가중치       :   2   3   4   5   6   7   8   9   2   3   4   5
//		곱의 합		 :  16   9   0  20  12  14   8   9  16  15  24   0 => 143

//		143 % 11 =>  0		11 -  0 = 11 % 10 = 1 와 주민등록번호의 마지막 자리가
//                   1            1   10        0    같으면 정상
//					 2            2    9        9
//				   ...          ...  ...      ...
//					10           10    1        1
		
//		주민등록번호의 각 자리 숫자에 가중치를 곱한 합계를 계산한다.
		sum = 0;
		for(var i = 0; i < 12; i++) {
//			sum += jumin.charAt(i) * (i < 8 ? i + 2 : i - 6);
			sum += jumin.charAt(i) * (i % 8 + 2);
		}
//		alert(sum);

		var result = (11 - sum % 11) % 10;
		if(result != jumin.charAt(12)) {
			alert("주민등록번호가 올바르지 않습니다.");
			obj.j1.value = "";
			obj.j2.value = "";
			obj.j1.focus();
			return false;
		}
		
//		오류없이 여기까지 실행되면 정상적인 데이터가 입력된 것이므로 true를 리턴한다.
		return true;
	}
