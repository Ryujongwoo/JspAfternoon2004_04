# insert into 테이블이름 (필드이름, ...) values (데이터, ...);
INSERT INTO memolist (NAME, PASSWORD, memo, ip) 
VALUES ('홍길동', '1111', '1등 입니다.', '192.168.100.101');
INSERT INTO memolist (NAME, PASSWORD, memo, ip) 
VALUES ('임꺽정', '2222', '2등 입니다.', '192.168.100.102');
INSERT INTO memolist (NAME, PASSWORD, memo, ip) 
VALUES ('장길산', '3333', '3등 입니다.', '192.168.100.103');
INSERT INTO memolist (NAME, PASSWORD, memo, ip) 
VALUES ('일지매', '4444', '4등 입니다.', '192.168.100.104');

# select [distinct]필드이름 또는 * from 테이블이름;
# distinct : 생략가능, 중복되는 데이터는 한 번만 출력한다.
# * : 모든 필드
SELECT NAME, memo FROM memolist;
SELECT * FROM memolist;
SELECT DISTINCT NAME FROM memolist;
# select * from 테이블이름 order by 필드이름 [asc/desc];
# order by : 정렬, 생략시 asc(오름차순), desc(내림차순)
SELECT * FROM memolist ORDER BY idx DESC; # 최신글순서
# select * from 테이블이름 where 조건;
SELECT * FROM memolist WHERE NAME = '홍길동';
SELECT * FROM memolist WHERE NAME = '임꺽정';
SELECT * FROM memolist WHERE NAME = '홍길동' || NAME = '임꺽정';
SELECT * FROM memolist WHERE NAME = '장길산' OR NAME = '일지매';
SELECT * FROM memolist WHERE NAME IN ('홍길동', '임꺽정', '장길산');
SELECT * FROM memolist WHERE NAME NOT IN ('홍길동', '임꺽정', '장길산');
SELECT * FROM memolist WHERE idx = 10;
SELECT * FROM memolist WHERE idx >= 10 && idx <= 15;
SELECT * FROM memolist WHERE idx >= 10 AND idx <= 15;
SELECT * FROM memolist WHERE idx BETWEEN 10 AND 15;
# 부분일치 조건 => like 연산자와 와일드 카드(대체 문자)를 사용한다.
# 대체 문자 : % => 여러 문자를 대신할 수 있다. _ => 1문자를 대신한다.
# 홍% => 홍으로 시작하는, %홍 => 홍으로 끝나는, %홍% => 홍을 포함하는
SELECT * FROM memolist WHERE NAME LIKE '_길_';
SELECT * FROM memolist WHERE NAME LIKE '홍%';
SELECT * FROM memolist WHERE NAME LIKE '%매';
SELECT * FROM memolist WHERE NAME LIKE '%길%';
# limit를 사용하면 특정 인덱스 부터 지정한 개수만큼 데이터를 얻어올 수 있다.
# limit 시작인덱스, 얻어올 데이터의 개수
# index란 select 명령을 실행했을 때 출력되는 순서로 맨 처음 index는 0부터 시작한다.
SELECT * FROM memolist ORDER BY idx DESC;
SELECT * FROM memolist ORDER BY idx DESC LIMIT 0, 10;
SELECT * FROM memolist ORDER BY idx ASC;
SELECT * FROM memolist ORDER BY idx ASC LIMIT 0, 10;