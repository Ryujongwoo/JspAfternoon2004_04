package kr.koreait.service;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.ibatis.session.SqlSession;

import kr.koreait.dao.MvcBoardDAO;
import kr.koreait.mybatis.MySession;
import kr.koreait.vo.MvcBoardList;
import kr.koreait.vo.MvcBoardVO;

public class MvcBoardService {

	private static MvcBoardService instance = new MvcBoardService();
	private MvcBoardService() { }
	public static MvcBoardService getInstance() { return instance; }
	
//	insertOK.nhn으로 요청이 들어오면 컨트롤러에서 실행되는 메소드로 테이블에 저장할 메인글이 저장된 request 객체를 넘겨받고 mapper를 얻어오는
//	메소드
	public void insert(HttpServletRequest request, HttpServletResponse response) {
		System.out.println("MvcBoardService 클래스의 insert 메소드 실행");
//		System.out.println(request.getParameter("name"));
//		System.out.println(request.getParameter("subject"));
//		System.out.println(request.getParameter("content"));
		SqlSession mapper = MySession.getSession();
		
//		request 객체로 넘어온 insert.jsp에서 form에 입력한 데이터를 받아서 MvcBoardVO 클래스 객체에 저장한다.
		String name = request.getParameter("name");
		String subject = request.getParameter("subject");
		String content = request.getParameter("content");
		MvcBoardVO vo = new MvcBoardVO(name, subject, content);
		
//		dao 클래스의 insert.jsp에서 입력한 데이터를 저장하는 insert sql 명령을 실행하는 메소드를 실행한다.
		MvcBoardDAO.getInstance().insert(mapper, vo);
		mapper.commit();
		mapper.close();
	}
	
//	list.nhn으로 요청이 들어오면 컨트롤러에서 실행되는 브라우저에 표시할 페이지 번호를 넘겨받고 mapper를 얻어온 후 브라우저에 출력할 1페이지 
//	분량의 글 목록과 페이지 작업에 사용할 8개의 변수를 기억하는 클래스 객체를 만들어서 request 영역에 저장하는 메소드
	public void selectList(HttpServletRequest request, HttpServletResponse response) {
		System.out.println("MvcBoardService 클래스의 selectList 메소드 실행");
		SqlSession mapper = MySession.getSession();
		MvcBoardDAO dao = MvcBoardDAO.getInstance();
		
//		list.nhn이 요청될 때 넘어오는 브라우저에 표시할 페이지 번호를 받는다.
//		브라우저에 표시할 페이지 번호가 정상적으로 넘어왔으면 넘어온 페이지 번호로, 정상적으로 넘어오지 않았다면 1로 브라우저에 표시할 페이지
//		번호를 설정한다.
		int currentPage = 1;
		try {
			currentPage = Integer.parseInt(request.getParameter("currentPage"));
		} catch(Exception e) { }
		
//		1페이지에 표시할 글의 개수를 정한다.
		int pageSize = 10;
//		테이블에 저장된 전체 글의 개수를 얻어온다.
		int totalCount = dao.selectCount(mapper);
//		System.out.println(totalCount);
		
//		1페이지 분량의 글과 페이지 작업에 사용되는 8개의 변수를 초기화 시키는 클래스(MvcBoardList)의 객체를 만든다.
		MvcBoardList mvcBoardList = new MvcBoardList(pageSize, totalCount, currentPage);
//		1페이지 분량의 시작, 끝 인덱스를 기억한는 HashMap 객체를 만들고 초기화 시킨다.
		HashMap<String, Integer> hmap = new HashMap<String, Integer>();
		hmap.put("startNo", mvcBoardList.getStartNo());
		hmap.put("endNo", mvcBoardList.getEndNo());
//		1페이지 분량의 글을 얻어와서 MvcBoardList 클래스의 ArrayList에 넣어준다.
		mvcBoardList.setMvcBoardList(dao.selectList(mapper, hmap));
//		System.out.println(mvcBoardList);
//		MvcBoardList 클래스 객체를 request 영역에 저장한다.
		request.setAttribute("mvcBoardList", mvcBoardList);
		mapper.close();
	}
	
//	increment.nhn으로 요청이 들어오면 컨트롤러에서 실행되는 메소드로 조회수를 증가시킬 글번호를 넘겨받고 mapper를 얻어오는 메소드
	public void increment(HttpServletRequest request, HttpServletResponse response) {
		System.out.println("MvcBoardService 클래스의 increment 메소드 실행");
		SqlSession mapper = MySession.getSession();
//		request 객체로 넘어오는 조회수를 증가시킬 글번호를 받는다.
		int idx = Integer.parseInt(request.getParameter("idx"));
//		조회수를 증가시키는 메소드를 호출한다.
		MvcBoardDAO.getInstance().increment(mapper, idx);
		mapper.commit();
		mapper.close();
	}
	
//	contentView.nhn으로 요청이 들어오면 컨트롤러에서 실행되는 메소드로 조회수를 증가시킨 글의 글번호를 넘겨받고 mapper를 얻어와서 request 영역에
//	저장하는 메소드
	public void selectByIdx(HttpServletRequest request, HttpServletResponse response) {
		System.out.println("MvcBoardService 클래스의 selectByIdx 메소드 실행");
		SqlSession mapper = MySession.getSession();
//		request 객체로 넘어오는 얻어올 글번호와 작업 후 돌아갈 페이지 번호를 받는다.
		int idx = Integer.parseInt(request.getParameter("idx"));
		int currentPage = Integer.parseInt(request.getParameter("currentPage"));
//		조회수를 증가시킨 글(브라우저에 표시할 글) 1건을 얻어와 MvcBoardVO 클래스 객체에 저장한다.
		MvcBoardVO vo = MvcBoardDAO.getInstance().selectByIdx(mapper, idx);
//		브라우저에 표시할 글이 저장된 객체, 작업 후 돌아갈 페이지 번호, 줄바꿈에 사용할 이스케이프 시퀀스를 request 영역에 저장한다.
		request.setAttribute("vo", vo);
		request.setAttribute("currentPage", currentPage);
		request.setAttribute("enter", "\r\n");
		mapper.close();
	}
	
//	delete.nhn으로 요청이 들어오면 컨트롤러에서 실행되는 메소드로 mapper를 얻어오고 글 1건을 삭제하는 메소드
	public void delete(HttpServletRequest request, HttpServletResponse response) {
		System.out.println("MvcBoardService 클래스의 delete 메소드 실행");
		SqlSession mapper = MySession.getSession();
//		request 객체로 넘어오는 삭제할 글번호를 받아서 글번호에 해당되는 글을 삭제하는 메소드를 호출한다.
		int idx = Integer.parseInt(request.getParameter("idx"));
		MvcBoardDAO.getInstance().delete(mapper, idx);
		mapper.commit();
		mapper.close();
	}
	
//	update.nhn으로 요청이 들어오면 컨트롤러에서 실행되는 메소드로 mapper를 얻어오고 글 1건을 수정하는 메소드
	public void update(HttpServletRequest request, HttpServletResponse response) {
		System.out.println("MvcBoardService 클래스의 update 메소드 실행");
		SqlSession mapper = MySession.getSession();
//		request 객체로 넘어오는 수정할 글번호, 수정할 데이터를 받아서 MvcBoardVO 클래스 객체에 저장한 후 글을 수정하는 메소드를 호출한다.
		int idx = Integer.parseInt(request.getParameter("idx"));
		String subject = request.getParameter("subject");
		String content = request.getParameter("content");
		MvcBoardVO vo = new MvcBoardVO();
		vo.setIdx(idx);
		vo.setSubject(subject);
		vo.setContent(content);
		MvcBoardDAO.getInstance().update(mapper, vo);
		mapper.commit();
		mapper.close();
	}
	
//	replyInsert.nhn으로 요청이 들어오면 컨트롤러에서 실행되는 메소드로 mapper를 얻어오고 조건에 만족하는 seq를 1씩 증가 시킨 후 답글을 저장하는
//	메소드
	public void replyInsert(HttpServletRequest request, HttpServletResponse response) {
		System.out.println("MvcBoardService 클래스의 replyInsert 메소드 실행");
		SqlSession mapper = MySession.getSession();
		MvcBoardDAO dao = MvcBoardDAO.getInstance();

//		request 객체로 넘어오는 데이터를 받는다.
		int idx = Integer.parseInt(request.getParameter("idx"));
		int ref = Integer.parseInt(request.getParameter("ref"));
		int lev = Integer.parseInt(request.getParameter("lev"));
		int seq = Integer.parseInt(request.getParameter("seq"));
		int currentPage = Integer.parseInt(request.getParameter("currentPage"));
		String name = request.getParameter("name");
		String subject = request.getParameter("subject");
		String content = request.getParameter("content");
		
//		MvcBoardVO 클래스에 저장한다.
//		답글은 질문글보다 안쪽으로 들여쓰기를 해야하기 때문에 lev가 1커야 하고 질문글 바로 아래에 나와야 하기 때문에 seq도 1 커야한다.
		MvcBoardVO vo = new MvcBoardVO(name, subject, content);
		vo.setIdx(idx);
		vo.setRef(ref);
		vo.setLev(lev + 1);
		vo.setSeq(seq + 1);
		
//		같은 글 그룹(ref)에서 답글이 삽입될 위치(seq) 이후 모든 글이 출력될 위치를 1씩 증가시키는 메소드를 실행한다.
		HashMap<String, Integer> hmap = new HashMap<String, Integer>();
		hmap.put("ref", vo.getRef());
		hmap.put("seq", vo.getSeq());
		dao.incrementSeq(mapper, hmap);
		
//		답글을 저장하는 메소드를 실행한다.
		dao.insertReply(mapper, vo);
		
		mapper.commit();
		mapper.close();
	}
	
}














