package kr.koreait.vo;

import java.util.ArrayList;

//	댓글 목록을 기억하는 클래스
public class FreeboardCommentList {

	private ArrayList<FreeboardCommentVO> freeboardCommentList = new ArrayList<FreeboardCommentVO>();

	public ArrayList<FreeboardCommentVO> getFreeboardCommentList() {
		return freeboardCommentList;
	}
	public void setFreeboardCommentList(ArrayList<FreeboardCommentVO> freeboardCommentList) {
		this.freeboardCommentList = freeboardCommentList;
	}
	
	@Override
	public String toString() {
		return "FreeboardCommentList [freeboardCommentList=" + freeboardCommentList + "]";
	}
	
}
