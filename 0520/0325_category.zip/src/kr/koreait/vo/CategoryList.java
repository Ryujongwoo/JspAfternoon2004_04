package kr.koreait.vo;

import java.util.ArrayList;

public class CategoryList {

	private ArrayList<CategoryVO> categoryList = new ArrayList<CategoryVO>();		// 브라우저에 출력할 카테고리 목록을 기억한다.

	public ArrayList<CategoryVO> getCategoryList() {
		return categoryList;
	}
	public void setCategoryList(ArrayList<CategoryVO> categoryList) {
		this.categoryList = categoryList;
	}
	
	@Override
	public String toString() {
		return "CategoryList [categoryList=" + categoryList + "]";
	}
	
}
