package com.tjoeunit.service;

import org.apache.ibatis.session.SqlSession;

import com.tjoeunit.dao.CategoryDAO;
import com.tjoeunit.mybatis.MySession;
import com.tjoeunit.vo.CategoryList;
import com.tjoeunit.vo.CategoryVO;

public class CategoryService {

	private static CategoryService instance = new CategoryService();
	private CategoryService() { }
	public static CategoryService getInstance() { return instance; }
	
//	insert.jsp에서 호출되는 테이블에 저장할 메인 카테고리 정보가 저장된 객체를 넘겨받고 mapper를 얻어온 후 dao
//	클래스의 메인 카테고리를 저장하는 insert sql 명령을 실행하는 메소드를 호출하는 메소드
	public void insert(CategoryVO vo) {
		System.out.println("CategoryService 클래스의 insert() 메소드 실행");
//		mapper를 얻어온다.
		SqlSession mapper = MySession.getSession();
		
		CategoryDAO.getInstance().insert(mapper, vo);
		
//		테이블의 내용이 변경되는 insert, delete, update 명령을 실행한 경우 반드시 commit() 메소드를 실행해서
//		변경 사항을 적용시켜야 한다. => 테이블 내용이 변경되지 않는 select 명령은 실행하지 않아도 된다.
		mapper.commit();
//		데이터베이스 작업이 완료되면 반드시 mapper를 닫아야 한다.
		mapper.close();
	}
	
//	list.jsp에서 호출되는 mapper를 얻어온 후 dao 클래스의 테이블에 저장된 모든 카테고리를 얻어오는 select sql 명령을
//	실행하는 메소드를 호출하는 메소드
	public CategoryList selectList() {
		System.out.println("CategoryService 클래스의 selectList() 메소드 실행");
		SqlSession mapper = MySession.getSession();
//		카테고리 목록을 저장해 리턴시킬 객체를 선언한다.
		CategoryList categoryList = new CategoryList();
//		테이블에서 얻어온 전체 카테고리 목록을 CategoryList 클래스의 ArrayList에 저장한다.
		categoryList.setCategoryList(CategoryDAO.getInstance().selectList(mapper));
		mapper.close();
//		카테고리 목록을 리턴시킨다.
		return categoryList;
	}
	
}









